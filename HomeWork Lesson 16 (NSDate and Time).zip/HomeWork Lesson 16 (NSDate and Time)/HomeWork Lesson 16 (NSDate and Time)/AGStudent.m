//
//  AGStudent.m
//  HomeWork Lesson 16 (NSDate and Time)
//
//  Created by Anton Gorlov on 24.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"

@implementation AGStudent {
    NSDateFormatter*dateFormatter;
}
-(id) initWithID:(NSInteger)id {
    self=[super init];
    
    if(self) {
        NSDate*date=[NSDate date];
        NSCalendar*calendar=[NSCalendar currentCalendar];
        dateFormatter=[[NSDateFormatter alloc]init];
        NSDateComponents *components=[calendar components:NSCalendarUnitYear fromDate:date];
        
        [dateFormatter setDateFormat:@"dd/MM/yyyy"];
        NSInteger birthYear=[components year]- (arc4random()%35+16);
        self.age=[components year]-birthYear;
        
        [components setDay:arc4random()%32];
        [components setMonth:arc4random()%13];
        [components setYear:birthYear];
        
        self.dateOfBirth=[calendar dateFromComponents:components];
        self.name=[NSString stringWithFormat:@"Student_%ld",id]; // показывает нумерацию  студентов
        
    
    }
  
    return self;
}

-(NSString*) description {
    return [NSString stringWithFormat:@"%@  was born in %@ year.",self.name,[dateFormatter stringFromDate:self.dateOfBirth]];
}

-(void) printDateOfDirth {
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSLog(@"%@ %@ was born in %@ year.Now he is %ld years old",
          self.name,
          self.lastName,
          [dateFormatter stringFromDate:self.dateOfBirth],self.age);

}







@end
