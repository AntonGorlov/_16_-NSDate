//
//  ViewController.h
//  HomeWork Lesson 16 (NSDate and Time)
//
//  Created by Anton Gorlov on 24.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

