//
//  AGStudent.h
//  HomeWork Lesson 16 (NSDate and Time)
//
//  Created by Anton Gorlov on 24.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGStudent : NSObject
@property (strong,nonatomic) NSDate* dateOfBirth;
@property (strong,nonatomic) NSString* name;
@property (assign,nonatomic) NSInteger age;
@property (strong,nonatomic) NSString* lastName;



-(id)initWithID:(NSInteger)id;
-(void) printDateOfDirth;
-(void) calculateAgeDifferenceYoung:(NSDate*)date1 andOldStudent:(NSDate*) date2;
@end
