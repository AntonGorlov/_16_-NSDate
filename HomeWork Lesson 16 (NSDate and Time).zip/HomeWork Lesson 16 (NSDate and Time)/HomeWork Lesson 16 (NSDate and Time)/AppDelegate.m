//
//  AppDelegate.m
//  HomeWork Lesson 16 (NSDate and Time)
//
//  Created by Anton Gorlov on 24.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGStudent.h"
@interface AppDelegate ()

@property (strong,nonatomic) AGStudent* student;
@property (strong,nonatomic) NSArray* arraySortedStudents;
@property (strong,nonatomic) NSMutableArray* arrayStudents;
@property (weak,nonatomic) NSTimer* timer;
@property (assign,nonatomic) NSInteger countDay;
@property (assign,nonatomic) NSInteger countBirthDay;
@property (assign,nonatomic) NSInteger indexMin;
@property (assign,nonatomic) NSInteger indexMax;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
/*
 
    Ученик.
    
    1. Создайте класс студент у которого будет проперти dateOfBirth (дата рождения), которая собственно NSDate.
    2. Инициализируйте NSMutableArray и в цикле создайте 30 студентов.
    3. Каждому установите дату рождения. Возраст рандомный от 16 до 50 лет.
    4. В другом цикле пройдитесь по всему массиву и выведите день рождения каждого студента в адекватном формате.
  http://vk.com/topic?act=browse_images&id=-58860049_1084
*/
    
    //2й пункт.
    NSMutableArray*arrayStudents=[[NSMutableArray alloc]init];
        for (int i=0; i<=30; i++) {
            AGStudent*student=[[AGStudent alloc]initWithID:i];
            [arrayStudents addObject:student];
       // NSLog(@"%lu",[arrayStudents count]);
            
    }
    //4й пункт.
    
    for(AGStudent*studentID in arrayStudents){
        [studentID printDateOfDirth ];
    }

/*
    
     Студент.
     
     5. Отсортируйте массив студентов по дате рождения, начиная от самого юного.
     6. Используя массивы имен и фамилий (по 5-10 имен и фамилий), каждому студенту установите случайное имя и случайную фамилию.
     7. Выведите отсортированных студентов: Имя, Фамилия, год рождения
     http://vk.com/topic?act=browse_images&id=-58860049_1085
*/
    //5й пункт. sort students by dateOfBirth
   
   NSArray* arraySortedStudents=[arrayStudents sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
       return [[obj2 dateOfBirth]compare:[obj1 dateOfBirth]];
   }];
   
    
    NSLog(@"%@",arraySortedStudents);
    
    //6й пункт.Random set students firtName and lastName
    self.countDay=0;
    self.arrayStudents=[NSMutableArray array];
    NSArray*arrayFirstName=[NSArray arrayWithObjects:@"Anna ",
                                                   @"Karina",
                                                   @"Katja",
                                                   @"Vika",
                                                   @"Viktoria",
                                                   @"Olga",
                                                   @"Alina",
                                                   @"Marina",
                                                   @"Elena",
                                                   @"Sveta",
                                                   @"Oksana",
                                                   @"Milena",
                                                   @"Ulia",
                                                   @"Sasha",
                                                   @"Dasha",
                                                   @"Ela",
                                                   @"Nasja",
                                                   @"Natasha", nil];
 
    NSArray*arrayLastName=[NSArray arrayWithObjects:@"Андрекина",
                                                   @"Алгазина",
                                                   @"Асадуллина",
                                                   @"Кокорина",
                                                   @"Бабурина",
                                                   @"Бабуркина",
                                                   @"Бабурова",
                                                   @"Горлова",
                                                   @"Бердюгина",
                                                   @"Боборыкина",
                                                   @"Карасёва",
                                                   @"Катаева",
                                                   @"Катанаевa",
                                                   @"Коваль",
                                                   @"Коэн",
                                                   @"Кравченко",
                                                   @"Крутовских",
                                                   @"Кузнецова",
                                                   @"Гагарина", nil];
    
    
       for (AGStudent* student in arraySortedStudents){
        student.name=[arrayFirstName objectAtIndex:arc4random() %[arrayFirstName count]];
        student.lastName=[arrayLastName objectAtIndex:arc4random()%[arrayLastName count]];
           
    //7й print students list
        [student printDateOfDirth];
    }

    /*
     Мастер.
     
     10. Создайте таймер в апп делегате, который отсчитывает один день за пол секунды.
     11. Когда таймер доходит до дня рождения любого их студентов - поздравлять его с днем рождения.
     12. Выведите на экран разницу в возрасте между самым молодым и самым старым студентом (количество лет, месяцев, недель и дней)
     !!!все выглядит очень хорошо как обычно, молодец! Единственное что резало мой глаз это то число 8000 с чем-то. лучше если работаешь с датами и надо указать интервал в часах, то лучше 5 часов писать не как 18000, а как 5 * 60 * 60, тогда понятно что речь о часах идет, а 4 дня например лучше делать так 4 * 24 * 60 * 60; Ну а если это повторяется часто в коде, то лучше выносить в константу.
     
     Все это мы делаем для того, чтобы код был как можно более информативным, чтобы не надо было голову ломать что за 8 тыщ :)
     http://vk.com/topic?act=browse_images&id=-58860049_1086 код запустился с помощью Жени и строки 135 ! ! !
     */
    NSLog(@" ");
    NSLog(@" Level \"Master\" ");
    NSLog(@"***************************************************************************** ");
    NSLog(@" ");
    //10й - create timer
   self.arraySortedStudents = arraySortedStudents;//приравняем массивы,так как метод -(void) greetingStudent имеет внутренний массив,а он пустой, без студентов.
    self.timer=[NSTimer scheduledTimerWithTimeInterval:0.0005f//0.00005
                                                target:self
                                              selector:@selector(greetingStudent)
                                              userInfo:nil
                                               repeats:YES];
   
    //12й - calculate difference between young and old students
    
    AGStudent*youngStudent = [arraySortedStudents objectAtIndex:0];
    AGStudent*oldStudent=[arraySortedStudents objectAtIndex:[arraySortedStudents count]-1];
  
    NSDate* firstDate=youngStudent.dateOfBirth;
    NSDate* lastDate=oldStudent.dateOfBirth;
    
    NSCalendar* calendar = [NSCalendar currentCalendar];
    NSDateComponents* components = [calendar components: NSCalendarUnitYear |
                                    NSCalendarUnitMonth |
                                    NSCalendarUnitWeekOfYear |
                                    NSCalendarUnitDay
                                               fromDate:lastDate
                                                 toDate:firstDate
                                                options: NSCalendarWrapComponents];
    NSLog(@"Difference of age: %ld age, %ld months, %ld weeks, %ld days", [components year],[components month], [components weekday], [components day]);
    NSLog(@"Young student %@ %@",youngStudent.name,youngStudent.lastName);
    NSLog(@"Old student %@ %@",oldStudent.name,oldStudent.lastName);
    
    /*
     13. Выведите на экран день недели, для каждого первого дня каждого месяца в текущем году (от начала до конца)
     14. Выведите дату (число и месяц) для каждого воскресенья в текущем году (от начала до конца)
     15. Выведите количество рабочих дней для каждого месяца в текущем году (от начала до конца)
     (13 и 14й пункт)http://vk.com/topic?act=browse_images&id=-58860049_1087
     (15й пункт) http://vk.com/topic?act=browse_images&id=-58860049_1109
     */
    
    NSLog(@" ");
    NSLog(@" Level \"Superman\" ");
    NSLog(@"***************************************************************************** ");
    NSLog(@" ");
    
    
    NSLog(@"********* 13 пункт");
    //13й print week day every first month day in current year
    NSInteger countDays=0;
    NSDate* currentDate=[NSDate date];
    NSCalendar *calendarSupermanLevel=[NSCalendar currentCalendar];
    //выводим на экран день недели
    NSDateFormatter* dateFormatter=[[NSDateFormatter alloc]init];
    NSDateFormatter* weekFormatter=[[NSDateFormatter alloc]init];
    
    NSDateComponents* componentsSupermanLevel=[calendarSupermanLevel components:NSCalendarUnitYear
                                                          fromDate:currentDate];
    
    for (NSInteger i = 1; i <=12 ; i++) {
        //берем 1 день всех месяцев
        [componentsSupermanLevel setDay:1];
        [componentsSupermanLevel setMonth:i];
        
        [weekFormatter setDateFormat:@"EEEE"];
        [dateFormatter setDateStyle:NSDateFormatterShortStyle];
        [dateFormatter setDateFormat:@"dd.MM.yyy"];
        NSLog(@"Date %@ was %@ week day",[dateFormatter stringFromDate:[calendarSupermanLevel dateFromComponents:componentsSupermanLevel]], [weekFormatter stringFromDate:[calendarSupermanLevel dateFromComponents:componentsSupermanLevel]]);
    }
    
    NSLog(@"***** \n");
    NSLog(@"********* 14 пункт");
    //14й print day and month for every Sunday in current year
    
    NSDateComponents* componentsFourTeen=[[NSDateComponents alloc]init];
    [componentsFourTeen setYear:2015];
    [componentsFourTeen setMonth:12];
    [componentsFourTeen setDay:31];
    NSDate* dateLast=[calendarSupermanLevel dateFromComponents:componentsFourTeen];
    
    [componentsFourTeen setDay:1];
    [componentsFourTeen setMonth:1];
    NSDate* dateCurrent=[calendarSupermanLevel dateFromComponents:componentsFourTeen];
    
    while (![dateCurrent isEqualToDate:dateLast]) {//тукущая дата
        dateCurrent=[dateCurrent dateByAddingTimeInterval:(24 * 60 * 60)];//соз дату добавляя интервал
        componentsFourTeen=[calendarSupermanLevel components:
                             NSCalendarUnitWeekday
                            |NSCalendarUnitMonth
                            |NSCalendarUnitDay fromDate:dateCurrent];
        
        if ([componentsFourTeen weekday] == 1) {
            NSLog(@"%ld Sunday = %ld day in %ld month",++countDays,[componentsFourTeen day],[componentsFourTeen month]);
        }
    }
    NSLog(@"\n");
    NSLog(@"********* 15 пункт");
    //15. Выведите количество рабочих дней для каждого месяца в текущем году (от начала до конца)
    NSDate*date=[NSDate date];//или alloc init
    NSCalendar* calendarFifTeen=[NSCalendar currentCalendar];
    NSDateComponents* componentsFifTeen=[calendarFifTeen components:NSCalendarUnitYear | NSCalendarUnitMonth fromDate:date];
   //берем год и месяц
    NSInteger year=[componentsFifTeen year];
    NSInteger countMonth=[componentsFifTeen month];
    
    for (NSInteger month=0; month<=countMonth; month++) {
        NSInteger weekDay=0;
        NSInteger countWorkDays=0;
        [componentsFifTeen setMonth:month];
        [componentsFifTeen setYear:year];
        date=[calendar dateFromComponents:componentsFifTeen];
        
        NSRange monthDays= [calendar rangeOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitMonth forDate:date];
        NSInteger daysInMonth=monthDays.length;
        
        
        for (NSInteger day=0; day<daysInMonth; day++) {
            componentsFifTeen=[calendar components:NSCalendarUnitWeekday fromDate:date];
            weekDay =[componentsFifTeen weekday];
            date =[date dateByAddingTimeInterval:(24 * 60 * 60)];// добавляем интервал
            if (weekDay !=7 && weekDay !=1) {
                countWorkDays++;
            }
        }
        NSLog(@"Month %ld have %ld day- %ld work days",month,daysInMonth,countWorkDays);
    }
    return YES;
}

-(void) greetingStudent {
    
    //11й -creating student
  
    NSDateFormatter* dateFormatter=[[NSDateFormatter alloc]init];
    [dateFormatter setDateStyle:NSDateFormatterShortStyle];
    
    NSDate* birthDay=[NSDate dateWithTimeIntervalSinceNow: -(++self.countDay * 24 * 60 * 60)];
    NSString* stringBirthDay=[dateFormatter stringFromDate:birthDay];
   
   
    for (AGStudent* student in self.arraySortedStudents) {
        
        NSString* stringDateOfBirth= [dateFormatter stringFromDate:student.dateOfBirth];//распечатать дату.
        
        if ([stringBirthDay isEqualToString:stringDateOfBirth]) {
            [student printDateOfDirth];
            NSLog(@"%ld. Happy Birthday dear %@ %@! Happy Birthday to you!!!",self.countBirthDay,student.name,student.lastName);
            NSLog(@" ");
            ++self.countBirthDay;//нумерация студентов
            
        }
    }
    
    if (self.countDay % 366==0) {
        NSLog(@"Return some %ld year...",self.countDay/366);
    }
    if (self.countBirthDay==[self.arraySortedStudents count]) {
       [self.timer invalidate]; //вкл выкл таймера
    }

}










- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
